package podlifecycleconfig

const GroupName = "controllers.kube.book.au"
