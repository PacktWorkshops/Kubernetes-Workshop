// +k8s:deepcopy-gen=package
// +groupName=controllers.kube.book.au

package v1


